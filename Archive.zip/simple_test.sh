#!/usr/bin/env bash
# SENTINEL Unified Comprehensive Test Script
# Merges all major module, BLE.sh, snippet, TTY, and environment tests
# Version: 3.0.0

set -euo pipefail
trap 'echo -e "\033[0;31m[ERROR]\033[0m Error on line $LINENO"; exit 1' ERR

# Color setup
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[0;33m'
BLUE='\033[0;34m'
PURPLE='\033[0;35m'
CYAN='\033[0;36m'
NC='\033[0m'

SENTINEL_CONFIG="${HOME}/.sentinel/sentinel_config.sh"
SENTINEL_DIR="$(pwd)"

# Banner
cat <<EOF
${BLUE}
███████╗███████╗███╗   ██╗████████╗██╗███╗   ██╗███████╗██╗      
██╔════╝██╔════╝████╗  ██║╚══██╔══╝██║████╗  ██║██╔════╝██║      
███████╗█████╗  ██╔██╗ ██║   ██║   ██║██╔██╗ ██║█████╗  ██║      
╚════██║██╔══╝  ██║╚██╗██║   ██║   ██║██║╚██╗██║██╔══╝  ██║      
███████║███████╗██║ ╚████║   ██║   ██║██║ ╚████║███████╗███████╗ 
╚══════╝╚══════╝╚═╝  ╚═══╝   ╚═╝   ╚═╝╚═╝  ╚═══╝╚══════╝╚══════╝ 
${NC}${GREEN}Unified Comprehensive Test Script${NC}\nEOF

# Logging
log() { echo -e "${CYAN}[SENTINEL TEST]${NC} $*"; }
log_success() { echo -e "${GREEN}✓${NC} $*"; }
log_warn() { echo -e "${YELLOW}⚠${NC} $*"; }
log_error() { echo -e "${RED}✗${NC} $*"; }

# Section: Core File and Module System Tests
log "Testing core files and module system..."
for file in bashrc bash_aliases bash_functions bash_completion bash_modules; do
    if [[ -f "$SENTINEL_DIR/$file" ]]; then
        log_success "Found core file: $file"
    else
        log_error "Missing core file: $file"
    fi
done

if [[ -d "$SENTINEL_DIR/bash_modules.d" ]]; then
    log_success "Module directory exists"
    module_count=$(find "$SENTINEL_DIR/bash_modules.d" -type f -name "*.module" | wc -l)
    log "Found $module_count module files"
else
    log_error "Module directory does not exist"
fi

# Section: BLE.sh Installation, Loader, and TTY Tests
log "\n=== BLE.sh Installation, Loader, and TTY Tests ==="
BLESH_PATH="$HOME/.local/share/blesh/ble.sh"
LOADER_PATH="$HOME/.sentinel/blesh_loader.sh"

# Source installer module if available
INSTALLER_MODULE="$SENTINEL_DIR/bash_modules.d/blesh_installer.module"
if [[ -f "$INSTALLER_MODULE" ]]; then
    source "$INSTALLER_MODULE"
    log_success "Sourced blesh_installer.module"
else
    log_warn "blesh_installer.module not found, skipping installer tests"
fi

# Test uninstall and reinstall
if type -t uninstall_blesh &>/dev/null; then
    uninstall_blesh || log_warn "Uninstall failed (may not be installed)"
    log_success "Uninstall function ran"
fi
if type -t blesh_installer_main &>/dev/null; then
    blesh_installer_main || log_error "BLE.sh install failed"
    log_success "BLE.sh installed"
fi

# Loader test
if [[ -f "$LOADER_PATH" ]]; then
    source "$LOADER_PATH" && log_success "BLE.sh loader sourced" || log_error "BLE.sh loader failed"
else
    log_warn "BLE.sh loader script not found"
fi

# TTY fix test (from fix_blesh_tty.sh logic)
log "\n--- TTY State Fix Test ---"
stty sane; stty cooked; stty echo
if [[ -f "$BLESH_PATH" ]]; then
    # Patch and test detach function
    if ! grep -q "function ble-detach-sentinel" "$BLESH_PATH"; then
        cat >> "$BLESH_PATH" << 'EOL'
# SENTINEL patched detach function with comprehensive TTY fixes
function ble-detach-sentinel {
  local _saved_tty
  _saved_tty=$(stty -g 2>/dev/null || true)
  stty sane 2>/dev/null || true
  builtin eval -- "${_ble_detach_hook-}"
  ble/base/unload
  if [[ -n "$_saved_tty" ]]; then
    stty "$_saved_tty" 2>/dev/null || stty sane
  else
    stty sane; stty cooked; stty echo
  fi
  tput reset 2>/dev/null || true
}
function ble-detach { ble-detach-sentinel "$@"; }
EOL
        log_success "Patched BLE.sh detach function for TTY fixes"
    fi
    stty sane; stty cooked; stty echo
    log_success "TTY state reset"
else
    log_warn "BLE.sh not found for TTY patching"
fi

# Section: BLE.sh Loader and Option Tests (from test_blesh.sh, test_new_loader.sh)
log "\n--- BLE.sh Loader and Option Tests ---"
if [[ -f "$BLESH_PATH" ]]; then
    if source "$BLESH_PATH" --attach 2>/dev/null; then
        log_success "BLE.sh loaded with --attach"
    elif source "$BLESH_PATH" 2>/dev/null; then
        log_success "BLE.sh loaded without options"
    else
        log_error "Failed to load BLE.sh directly"
    fi
    bleopt | grep complete || log_warn "No 'complete' options found"
    bleopt | grep highlight || log_warn "No 'highlight' options found"
    bleopt complete_auto_delay=100
    bleopt complete_auto_complete=1
    log_success "BLE.sh options set"
else
    log_warn "BLE.sh not found for loader/option tests"
fi

# Section: Autocomplete and Fuzzy Correction Tests
log "\n=== Autocomplete and Fuzzy Correction Tests ==="
if [[ -d ~/.cache/blesh ]]; then rm -rf ~/.cache/blesh/*; fi
mkdir -p ~/.cache/blesh
if [[ -f ~/.sentinel/minimal_autocomplete.sh ]]; then
    source ~/.sentinel/minimal_autocomplete.sh
fi
if [[ -f ./bash_aliases.d/autocomplete ]]; then
    source ./bash_aliases.d/autocomplete && log_success "Autocomplete module loaded"
    if type -t @autocomplete &>/dev/null; then
        @autocomplete status || log_warn "@autocomplete status failed"
    fi
else
    log_warn "Autocomplete module not found"
fi

# Section: Snippet Management and Security Tests
log "\n=== Snippet Management and Security Tests ==="
SNIPPET_MODULE="$SENTINEL_DIR/bash_modules.d/snippets.module"
if [[ -f "$SNIPPET_MODULE" ]]; then
    source "$SNIPPET_MODULE"
    if type -t sentinel_snippet_list &>/dev/null; then
        sentinel_snippet_list || log_warn "Snippet list failed"
    fi
    if type -t sentinel_snippet_add &>/dev/null; then
        sentinel_snippet_add test_snip 'echo "Hello, Snippet!"' && log_success "Snippet add test passed" || log_warn "Snippet add failed"
        sentinel_snippet_show test_snip || log_warn "Snippet show failed"
        sentinel_snippet_delete test_snip && log_success "Snippet delete test passed" || log_warn "Snippet delete failed"
    fi
else
    log_warn "snippets.module not found"
fi

# Section: Cybersecurity, ML, and Chat Module Tests
log "\n=== Cybersecurity, ML, and Chat Module Tests ==="
if [[ -f "$SENTINEL_DIR/bash_modules.d/sentinel_ml.module" ]]; then
    log_success "ML module exists"
else
    log_warn "ML module not found"
fi
if [[ -f "$SENTINEL_DIR/bash_modules.d/sentinel_cybersec_ml.module" ]]; then
    log_success "Cybersecurity ML module exists"
else
    log_warn "Cybersecurity ML module not found"
fi
python3 -c "import sys; print('Python version:', sys.version)" || log_warn "Python not available"
python3 -c "import markovify; print('markovify version:', markovify.__version__)" 2>/dev/null || log_warn "markovify not installed"
python3 -c "import numpy; print('numpy version:', numpy.__version__)" 2>/dev/null || log_warn "numpy not installed"

# Section: Prompt and Bash Environment Tests
log "\n=== Prompt and Bash Environment Tests ==="
if type __set_prompt &>/dev/null; then
    __set_prompt; log_success "Prompt function exists"
else
    log_warn "__set_prompt function not found"
fi
if type __git_info &>/dev/null; then
    __git_info; log_success "Git info function exists"
else
    log_warn "__git_info function not found"
fi
if type __prompt_command_optimized &>/dev/null; then
    __prompt_command_optimized; log_success "Optimized prompt command exists"
else
    log_warn "__prompt_command_optimized function not found"
fi

# Section: Cleanup
log "\n=== Cleanup Temporary Files ==="
rm -f /tmp/sentinel_test_*.sh /tmp/sentinel_test_output /tmp/test_blesh_loader.sh /tmp/blesh_test_load.*
log_success "Temporary files cleaned up"

log "\n${GREEN}======== SENTINEL Unified Test Complete ========${NC}"
exit 0 