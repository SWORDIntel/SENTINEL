﻿## bashrc testing
This folder includes various scripts and helpers for developing bashrc.
Normal users probably don't need any of this.
